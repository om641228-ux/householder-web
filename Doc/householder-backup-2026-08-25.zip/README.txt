Бэкап householder — 2026-08-25T16:18:12.308Z

СОДЕРЖИМОЕ:
  tables/*.json — полный дамп всех таблиц базы (Supabase Postgres)
  files-manifest.json/csv — список ВСЕХ файлов с прямыми URL (сами файлы остаются в Supabase Storage и Cloudflare R2)

ТАБЛИЦЫ:
  receipts: 464
  doc_sections: 3
  objects: 0
  shares: 2
  document_pages: ОШИБКА: Could not find the table 'public.document_pages' in the schema cache
  bank_movements: 464
  planned_payments: 31
  proposals: 2
  contract_documents: 13
  crm_contacts: 1
  crm_counterparties: 1
  crm_tasks: 4

Файлов в манифесте: 6342

НЕ ВХОДИТ: переменные окружения Railway (SUPABASE_*, GEMINI_*, GROQ_*, R2_*, пароли) — храните их отдельно в менеджере паролей!

-- v192: настройки приложения (переключатель движка эмбеддингов и др.)
-- Выполнить один раз: Supabase → SQL Editor
create table if not exists app_settings (
  key text primary key,
  value text,
  updated_at timestamptz not null default now()
);
-- значение по умолчанию: авто (локальный → облако)
insert into app_settings (key, value) values ('embed_backend', 'auto')
on conflict (key) do nothing;

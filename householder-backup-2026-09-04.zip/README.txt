Бэкап householder — 2026-09-04T15:31:10.646Z

СОДЕРЖИМОЕ:
  tables/*.json — полный дамп всех таблиц базы (Supabase Postgres)
  files-manifest.json/csv — список ВСЕХ файлов с прямыми URL (сами файлы остаются в Supabase Storage и Cloudflare R2)

ТАБЛИЦЫ:
  receipts: 506
  doc_sections: 3
  objects: 0
  shares: 2
  document_pages: ОШИБКА: Could not find the table 'public.document_pages' in the schema cache
  bank_movements: 464
  cash_movements: 6
  planned_payments: 31
  proposals: 3
  contract_documents: 13
  crm_contacts: 1
  crm_counterparties: 1
  crm_tasks: 4
  chat_messages: 7
  chat_reads: 6
  app_users: 3
  activity_log: 311

Файлов в манифесте: 6423

НЕ ВХОДИТ: переменные окружения Railway (SUPABASE_*, GEMINI_*, GROQ_*, R2_*, пароли) — храните их отдельно в менеджере паролей!

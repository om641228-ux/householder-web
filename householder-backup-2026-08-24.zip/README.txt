Бэкап householder — 2026-08-24T14:23:02.681Z

СОДЕРЖИМОЕ:
  tables/*.json — полный дамп всех таблиц базы (Supabase Postgres)
  files-manifest.json/csv — список ВСЕХ файлов с прямыми URL (сами файлы остаются в Supabase Storage и Cloudflare R2)

ТАБЛИЦЫ:
  receipts: 462
  doc_sections: 3
  objects: 0
  shares: 2
  document_pages: ОШИБКА: Could not find the table 'public.document_pages' in the schema cache
  bank_movements: 465
  planned_payments: 28
  proposals: 2
  contract_documents: 13
  crm_contacts: 1
  crm_counterparties: 1
  crm_tasks: 4

Файлов в манифесте: 6340

НЕ ВХОДИТ: переменные окружения Railway (SUPABASE_*, GEMINI_*, GROQ_*, R2_*, пароли) — храните их отдельно в менеджере паролей!
